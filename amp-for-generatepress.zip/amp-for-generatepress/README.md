# AMP for GeneratePress

This small plugin fixes incompatibilies with [GeneratePress](https://generatepress.com) and the [AMP plugin](https://wordpress.org/plugins/amp/).

For now, this plugin focuses on fixing the mobile menu when using AMP. As times goes on, we'll add deeper integration.
